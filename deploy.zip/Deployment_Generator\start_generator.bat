set GENERATOR_HOME=C:\Users\wgius\Deployment_Generator\Generator
set JAVA_HOME="C:\Program Files\Amazon Corretto\jdk15.0.1_9"
set CONF_FILE=test.conf
set CUSTOM_JAR=activemq-client-5.16.0.jar

set cpath="%GENERATOR_HOME%";"%GENERATOR_HOME%\example-StockList-JMS-adapter-java-0.0.1-SNAPSHOT.jar";"%GENERATOR_HOME%\lib\*"
set class=com.lightstreamer.stocklist_jms_demo.feed_simulator.Generator

set command=%JAVA_HOME%\bin\java.exe -cp %cpath% %class% %CONF_FILE%

%command%
pause

