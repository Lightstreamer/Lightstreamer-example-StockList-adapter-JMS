#! /bin/sh

GENERATOR_HOME=/usr/Generator
JAVA_HOME=/usr/jdk1.7.0
CONF_FILE=test.conf
CUSTOM_JAR=tibjms.jar

cpath="$GENERATOR_HOME/StockQuotesGeneratorJMS.jar:$GENERATOR_HOME/lib/log4j-1.2.17.jar:$GENERATOR_HOME/lib/$CUSTOM_JAR:$GENERATOR_HOME/lib/jms.jar"
class=com.lightstreamer.stocklist_jms_demo.feed_simulator.Generator

command=$JAVA_HOME/bin/java -cp $cpath $class $CONF_FILE

touch "$GENERATOR_HOME"/logs/SLGenerator.log
exec $command >> "$GENERATOR_HOME"/logs/SLGenerator.log 2>&1 &